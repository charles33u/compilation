/**
* Exemple
*/
package generated.fr.ul.miage.test;

//tester le projet commentaire

public class test {
 
}
